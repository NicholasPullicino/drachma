<!-- search bar -->

<!-- the method is get as we are getting data -->
<form action="<?php echo home_url(''); ?>" method="GET">
    <input type="search" 
    name="s" 
    id="searchInput"
    placeholder="Search...">

    <button type="submit">Search</button>

</form>