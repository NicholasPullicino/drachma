<!-- All the website's header -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php wp_head(); ?>
    <?php wp_footer(); ?>
</head>

<body <?php body_class(); ?>>
  
<?php $header_bg = get_theme_mod('custom_header_bg', 'light'); ?>

<header class= "header-<?php echo $header_bg; ?>">



  <a href="#default" class="logo">Drachma</a>
  <div class="header-right">
  <!-- <?php echo do_shortcode( '[searchandfilter fields="search,category,post_tag"]' ); ?>
    <?php wp_nav_menu(array(
        'theme_location' => 'main-menu'
      )); ?> -->

    <ul class="grid_container">
      <li><a href="#home">Home</a></li>
      <li><a href="#news">About</a></li>
      <li><a href="#contact">Posts</a></li>
      <div class="search-container">
      <form action="/action_page.php">
        <input type="text" placeholder="Search.." name="search"></i></button>
      </form>
    </div>
    </ul>

  </div>

</header>
<body>
    
